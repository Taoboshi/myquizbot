# OZIZ Quiz Bot — refactored

Запуск остался прежним:

```bash
python telegram_quiz_bot.py
```

Структура:

```text
telegram_quiz_bot.py
quiz_bot/
  app.py
  admin.py
  config.py
  handlers.py
  helpers.py
  keyboards.py
  loader.py
  quiz.py
  runtime.py
  state.py
  storage.py
```

Папку `tests/` с JSON-файлами вопросов нужно держать рядом с `telegram_quiz_bot.py`.
